<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('admin/home', 'HomeController@adminHome')->name('admin.home')->middleware('is_admin');

Route::get('/back', 'ControllerFrontend@cek');

//Mahasiswa
Route::get('/mahasiswa', 'ControllerStudent@index');

// Frontend
Route::get('/', 'ControllerFrontend@index');
Route::get('/pemerintah', 'ControllerFrontend@pemerintah');
Route::get('/bpd', 'ControllerFrontend@bpd');
Route::get('/visimisi', 'ControllerFrontend@visimisi');
Route::get('/lpm', 'ControllerFrontend@lpm');
Route::get('/defnaker', 'ControllerFrontend@defnaker');

//familycard
Route::get('/family', 'familycardController@index');
Route::get('/family/cari','familycardController@cari');
Route::get('/family/create','familycardController@create');
Route::post('/family','familycardController@store');
Route::get('/family/cetak_pdf','familycardController@cetak_pdf');

Route::get('/family/edit/{id}', 'familycardController@edit');
Route::put('/family/update/{id}', 'familycardController@update');
Route::get('/family/hapus/{id}', 'familycardController@delete');

//population
Route::get('/population', 'familycardController@penduduk');
Route::get('/population/cari','familycardController@caripenduduk');
//population
Route::get('/perempuan', 'familycardController@perempuan');
Route::get('/perempuan/cari','familycardController@cariperempuan');

//suratsurat
Route::get('/surat','suratController@surattdkmampu');


//UPLOAD
Route::get('/upload','uploadController@upload');
Route::post('/upload/proses', 'UploadController@proses_upload');



