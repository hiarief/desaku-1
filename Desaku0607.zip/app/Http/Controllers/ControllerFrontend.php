<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Familycards;

class ControllerFrontend extends Controller
{
    public function index()
    {    

        return view('frontend.index');

    }
    public function cek()
        {
           // $kk = Familycards::groupby('kk')->paginate();
            $kk = Familycards::groupBy('kk')
            ->selectRaw('count(*) as total, kk')
            ->get();
            
            $nik = DB::table('familycards')->get();
            $perempuan = Familycards::where('jenis_kelamin','P')->get();
            $laki2 = Familycards::where('jenis_kelamin','L')->get();

            $data= [
                'kk'=>$kk,
                'nik'=>$nik,
                'perempuan'=>$perempuan,
                'laki2'=>$laki2
            ];


            return view('layout.cont',$data);
        }
    public function pemerintah()
    {
        return view('frontend.pemerintah');
    }
    public function bpd()
    {
        return view('frontend.bpd');
    }
    public function visimisi()
    {
        return view('frontend.visimisi');
    }
    public function lpm()
    {
        return view('frontend.lpm');
    }
    public function defnaker()
    {
        return view('frontend.job');
    }

}
