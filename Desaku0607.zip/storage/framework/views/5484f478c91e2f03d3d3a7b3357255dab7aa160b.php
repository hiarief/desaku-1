<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>surat tidak mampu</title>
</head>
        <table border="1" align="center"> 
            <tr>
        <td><img src="<?php echo e(('image/tangkab.png')); ?>" width="110" height="110"></td>
        <td align="center"><font size="4" >PEMERINTAH KABUPATEN TANGERANG</font><BR>
            <font size="4">KECAMATAN JAYANTI</font><BR>
            <font size="8">DESA SUMURBANDUNG</font><BR>
            <font size="2"><i>Jl. Raya Serang KM. 32 Desa. Sumurbandung Kec. Jayanti Kab. Tangerang Kode Pos: 15610</i></font><BR>
            <font size="2"><i>WEB : www.desaku.com EMAIL:desaku@gmail.com</i></font><BR>
            </td>
        </tr>
        <tr>
            <td colspan="2"><hr></td>
        </tr>
        <tr>
            <td colspan="2" align="center"><font size="4"><u>SURAT KETERANGAN TIDAK MAMPU</u></font></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Yang bertanda tangan di bawah ini, Kepala Desa Sumurbandung Kecamatan Jayanti Kabupaten Tangerang,<br> menerangkan bahwa</td>
        </tr>
        </table>
        <table align="center" border="1">
            <tr>
                <td>Nama</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Tempat, Tgl Lahir</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Status Perkawinan</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Pekerjaan</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td height="50" colspan="2">Anak Dari Seorang Ayah :</td>
            </tr>
            <tr>
                <td>Nama</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Tempat, Tgl Lahir</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Status Perkawinan</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Pekerjaan</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td height="50" colspan="2">Dengan seorang Ibu :</td>
            </tr>
            <tr>
                <td>Nama</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Tempat, Tgl Lahir</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Status Perkawinan</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Pekerjaan</td>
                <td width="500"> :</td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td width="500"> :</td>
            </tr>
            
        </table>
        <table border="1" align="center"> 
        <tr>
            <td colspan="2" align="justify">Nama tersebut diatas benar-benar warga Desa Sumurbandung, Kecamatan Jayanti, Kabupaten Tangerang, <br>dan menurut pengamatan kami dan data yang ada sampai saat ini termasuk keluarga yang tidak mampu / <br> dibawah garis kemiskinan.</td>
        </tr>
        <tr>
            <td colspan="2" align="justify">Demikian surat keterangan ini dibuat dengan sebenarnya, untuk dapat dipergunakan sebagaimana mestinya.</td>
        </tr>
        <tr>
            <td colspan="2" align="right">Tangerang,...........................................</td>
        </tr>
        <tr>
            <td height="20" colspan="2"></td>
        </tr>
        <tr>
            <td colspan="2" align="right">Kepala Desa Sumurbandung</td>
        </tr>
        <tr>
            <td height="50" colspan="2"></td>
        </tr>
        <tr>
            <td colspan="2" width="400" align="right">Ahmad Jajuli,SE</td>
        </tr>
        </table>
<body>
</body>
</html><?php /**PATH C:\xampp\htdocs\Desaku\resources\views/suratsurat/tidakmampu.blade.php ENDPATH**/ ?>