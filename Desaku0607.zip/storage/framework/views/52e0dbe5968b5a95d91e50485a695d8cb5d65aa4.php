<html>
<head>
	<title>LAPORAN KEPALA KELUARGA</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>KARTU KELUARGA</h4>
		</center>
                    
             
                        <table class="table table-sm table-responsive-sm" border="1">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">KK</th>
                                    <th scope="col">NIK</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Tempat Lahir</th>
                                    <th scope="col">Tgl Lahir</th>
                                    <th scope="col">S Perkawinan</th>
                                    <th scope="col">Jenis Kelamin</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">RT</th>
                                    <th scope="col">RW</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $familycards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($fm->kk); ?></td>
                                        <td><?php echo e($fm->nik); ?></td>
                                        <td><?php echo e($fm->nama); ?></td>
                                        <td><?php echo e($fm->tempat_lahir); ?></td>
                                        <td><?php echo e($fm->tgl_lahir); ?></td>
                                        <td><?php echo e($fm->status_perkawinan); ?></td>
                                        <td><?php echo e($fm->jenis_kelamin); ?></td>
                                        <td><?php echo e($fm->alamat); ?></td>
                                        <td><?php echo e($fm->rt); ?></td>
                                        <td><?php echo e($fm->rw); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
             
            </body>
            </html>
                            
                            
<?php /**PATH C:\xampp\htdocs\Desaku\resources\views/familycards/pdf.blade.php ENDPATH**/ ?>