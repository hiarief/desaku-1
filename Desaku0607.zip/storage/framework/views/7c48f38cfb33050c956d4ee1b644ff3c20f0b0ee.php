<?php $__env->startSection('content'); ?>

        <h1 class="mt-3">PENDUDUK</h1>
        <div class="container">
        <div class="row">
            
            <div class="col-md-4">   
                
                <form action="/population/cari" method="GET">
                    
                    <div class="input-group mb-3">
                        <input type="text" class="form-control"  name="cari" placeholder="cari nik" aria-label="Cari Nik" value="<?php echo e(old('cari')); ?>" aria-describedby="button-addon2">
                        <div class="input-group-append">
                          <button class="btn btn-outline-secondary" type="submit"  value="cari" id="button-addon2">Cari</button>
                        </div>
                      </div>
                </form>
            </div>
        </div>
        </div>
        
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table  table-hover table-responsive-sm">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">NIK</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Tempat Lahir</th>
                                <th scope="col">Tgl Lahir</th>
                                <th scope="col">S Perkawinan</th>
                                <th scope="col">Jenis Kelamin</th>
                                <th scope="col">Alamat</th>
                                <th scope="col">RT</th>
                                <th scope="col">RW</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $familycards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($fm->nik); ?></td>
                                <td><?php echo e($fm->nama); ?></td>
                                <td><?php echo e($fm->tempat_lahir); ?></td>
                                <td><?php echo e($fm->tgl_lahir); ?></td>
                                <td><?php echo e($fm->status_perkawinan); ?></td>
                                <td><?php echo e($fm->jenis_kelamin); ?></td>
                                <td><?php echo e($fm->alamat); ?></td>
                                <td><?php echo e($fm->rt); ?></td>
                                <td><?php echo e($fm->rw); ?></td>
                                <td>
                                    <a href="#" class="badge badge-success">Show</a>
                                    <a href="#" class="badge badge-danger">Hapus</a>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                        <br>
                            Halaman : <?php echo e($familycards ->currentPage()); ?> <br/>
                            Jumlah Data : <?php echo e($familycards ->total()); ?> <br/>
                            Data Per Halaman : <?php echo e($familycards->perPage()); ?> <br/>
                        
                        
                            <?php echo e($familycards ->links()); ?>

                        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Desaku\resources\views/penduduk/index.blade.php ENDPATH**/ ?>