<?php $__env->startSection('berita'); ?>
<body class="hold-transition skin-blue layout-boxed sidebar-mini">

<div class="container">
    <div class="mt-3">
        <div class="row">
            
            
            <img src="image/visimisi.jpg" class="img-fluid" alt="Responsive image">
            
        </div>
    
    </div>
</div>
    
<?php $__env->stopSection(); ?>
       
<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Desaku\resources\views/frontend/visimisi.blade.php ENDPATH**/ ?>