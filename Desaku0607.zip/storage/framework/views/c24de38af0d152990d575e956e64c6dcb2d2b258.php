<?php $__env->startSection('content'); ?>

        <h1 class="mt-3">KEPALA KELUARGA</h1>
        <div class="container">
        <div class="row">
            <div class="col-6">    
                <a href="/family/create" class="btn btn-primary my-3">Tambah Data</a>
            </div>
            <div class="col-6">   
                
                <form action="/family/cari" method="GET">
                    
                    <div class="input-group mb-6">
                        <input type="text" class="form-control"  name="cari" placeholder="No KK" aria-label="Jenis Kelamin" value="<?php echo e(old('cari')); ?>" aria-describedby="button-addon2">
                        <div class="input-group-append">
                          <button class="btn btn-outline-secondary" type="submit"  value="cari" id="button-addon2">Cari</button>
                        </div>
                      </div>
                </form>
        </div>
        </div>
        
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-responsive-sm">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">KK</th>
                                    <th scope="col">NIK</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Tempat Lahir</th>
                                    <th scope="col">Tgl Lahir</th>
                                    <th scope="col">S Perkawinan</th>
                                    <th scope="col">Jenis Kelamin</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">RT</th>
                                    <th scope="col">RW</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $familycards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($fm->kk); ?></td>
                                    <td><?php echo e($fm->nik); ?></td>
                                    <td><?php echo e($fm->nama); ?></td>
                                    <td><?php echo e($fm->tempat_lahir); ?></td>
                                    <td><?php echo e($fm->tgl_lahir); ?></td>
                                    <td><?php echo e($fm->status_perkawinan); ?></td>
                                    <td><?php echo e($fm->jenis_kelamin); ?></td>
                                    <td><?php echo e($fm->alamat); ?></td>
                                    <td><?php echo e($fm->rt); ?></td>
                                    <td><?php echo e($fm->rw); ?></td>
                                    <td>
                                        <a href="/family/edit/<?php echo e($fm->id); ?>" class="badge badge-success">Edit</a>
                                        <a href="/family/hapus/<?php echo e($fm->id); ?>" class="badge badge-danger">Hapus</a>
                                </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        </div>
                        <br>
                            Halaman : <?php echo e($familycards ->currentPage()); ?> <br/>
                            Jumlah Data : <?php echo e($familycards ->total()); ?> <br/>
                            Data Per Halaman : <?php echo e($familycards->perPage()); ?> <br/>
                        
                        
                            <?php echo e($familycards ->links()); ?>

                            <br>
                            <a href="/family/cetak_pdf" class="btn btn-primary my-8"  target="_blank">Cetak</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Desaku\resources\views/familycards/index.blade.php ENDPATH**/ ?>