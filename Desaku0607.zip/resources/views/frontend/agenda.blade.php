
@endsection
       
<section class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="list-post">
					<h3 class="page-title">Agenda</h3>
					 
                                    <a href="/agenda/bimbingan-teknis-sipkd-92">
					    		<div class="content-post">
					    			<h3 class="title-post">Bimbingan Teknis SIPKD</h3>
					    			
					    			<p>20 Pebruari 2019 08:00</p>
					    			<p class="date-post">18 Pebruari 2019 | Oleh : Admin Bulelengkab</p>
					    		</div>
                            </a>
                </div>
            </div>
        </div>
    </div>
</section>