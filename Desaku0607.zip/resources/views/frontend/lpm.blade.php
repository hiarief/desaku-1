@extends('frontend.index')


@section('berita')
<body class="hold-transition skin-blue layout-boxed sidebar-mini">

<div class="container">
    <div class="mt-3">
        <div class="row">
            
            
            <img src="image/lpmdesa.jpg" class="img-fluid" alt="Responsive image">
            
        </div>
    
    </div>
</div>
    
@endsection
       